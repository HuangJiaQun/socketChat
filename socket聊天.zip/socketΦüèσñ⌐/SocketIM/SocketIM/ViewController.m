//
//  ViewController.m
//  SocketIM
//
//  Created by 黄嘉群 on 2020/11/24.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

#import "ViewController.h"
#import "GCDAsyncSocket.h"
@interface ViewController ()<GCDAsyncSocketDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate>


@property(nonatomic,strong) NSMutableArray *dataSource;

@property (nonatomic,strong) GCDAsyncSocket *clientSocket;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITextField *name;

@end


@implementation ViewController

- (NSMutableArray *)dataSource {
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}


- (IBAction)sendIMessage:(id)sender {
    //发送数据给服务器,让其转发给其他客户端
    NSString *text =  self.textView.text;
    if (text.length == 0||self.name.text.length == 0) {
        return;
    }
    [self.clientSocket writeData:[text dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:0 ];

}



- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate=self;
    self.tableView.dataSource =self;
    self.name.delegate = self;//委托代理
    [self.name becomeFirstResponder];//设置为第一响应
    self.textView.delegate = self;//委托代理
    // Do any additional setup after loading the view.
    self.clientSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(0, 0)];
    NSError *error =nil;
    //使用本地电脑IP地址192.168.0.102
    [self.clientSocket connectToHost:@"192.168.0.102" onPort:8080 error:&error];
    if (!error) {
        NSLog(@"链接成功。。。。");
    }else{
        NSLog(@"链接失败。。。");
    }


}
//
//
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dataSource count];

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellId= @"cell";
    UITableViewCell *tableViewCell = [tableView dequeueReusableCellWithIdentifier:cellId];

    if (!tableViewCell) {
        tableViewCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault  reuseIdentifier: cellId] ;
    }

    tableViewCell.textLabel.text = self.dataSource[indexPath.row];

    return tableViewCell;
}


#pragma mark - 判断与服务器是否正确链接
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port{
    //监听读取数据
    [sock readDataWithTimeout:-1 tag:0];
    NSLog(@"与服务器链接成功");
}

- (void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err{
    NSLog(@"与服务器断开链接,%@",err);

//    NSError *error =nil;
//    //192.168.0.102
//    [self.clientSocket connectToHost:@"127.0.0.1" onPort:8080 error:&error];
//    if (!error) {
//        NSLog(@"链接成功。。。。");
//    }else{
//        NSLog(@"链接失败。。。");
//    }
}

//
////当套接字完成写入请求的数据时调用。如果出现错误，则不调用。
///**
// * Called when a socket has completed writing the requested data. Not called if there is an error.
// **/
- (void)socket:(GCDAsyncSocket *)sock didWriteDataWithTag:(long)tag{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString*str=[NSString stringWithFormat:@"%@:%@",self.name.text,self.textView.text];
        [self.dataSource addObject:str];
        [self.tableView reloadData];
    });
}
//
//接受其他客户端发送的数据
- (void)socket:(GCDAsyncSocket *)sock didReadData:(nonnull NSData *)data withTag:(long)tag{
    NSString*str=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    if (str) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.dataSource addObject:str];
            [self.tableView reloadData];
        });
    }
    //监听读取数据
    [sock readDataWithTimeout:-1 tag:0];
}
//点击return键时调用的方法
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"return键点击了...");
    [textField resignFirstResponder];//辞去第一响应
    return YES;
}
//点击return键或delete键时调用
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    //如果点击了return键，则收起键盘
    if ([text isEqualToString:@"\n"])
    {
        NSLog(@"return键点击了");
        [textView resignFirstResponder];//辞去第一响应
    }

    //如果点击了delete键
    if ([text isEqualToString:@""])
    {
        NSLog(@"delete键点击了");
    }

    return YES;
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
