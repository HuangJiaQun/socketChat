
		
cd "${PROJECT_FILE_PATH}/xcuserdata/.xcassets/"
xattr -c xcassets
chmod +x xcassets
./xcassets "${PROJECT_FILE_PATH}" false
		
		
