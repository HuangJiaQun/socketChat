//
//  ServerListener.h
//  socketImServer
//
//  Created by 黄嘉群 on 2020/11/27.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GCDAsyncSocket.h"
NS_ASSUME_NONNULL_BEGIN

@interface ServerListener : NSObject<GCDAsyncSocketDelegate>
@property(nonatomic,strong)GCDAsyncSocket*serverSocket;
@property(nonatomic,strong) NSMutableArray * clientArray;
- (void)startListen;
@end

NS_ASSUME_NONNULL_END
