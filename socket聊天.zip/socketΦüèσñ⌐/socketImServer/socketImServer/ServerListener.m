//
//  ServerListener.m
//  socketImServer
//
//  Created by 黄嘉群 on 2020/11/27.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

#import "ServerListener.h"

@implementation ServerListener

-(NSMutableArray *)clientArray
{
    if (!_clientArray) {
        _clientArray = [NSMutableArray array];
    }
    return _clientArray;
}
- (void)startListen{
    //需要对服务端Socket进行强引用,否则创建完就销毁了
    self.serverSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(0, 0)];
    NSError *error = nil;
    //注意真机调试的时,所链接的网络要是局域网
    [self.serverSocket acceptOnPort:8080 error:&error];
    if (!error) {
        NSLog(@"服务端已经开启");
    }else{
        NSLog(@"服务端开启失败");
    }
    //[self.serverSocket readDataWithTimeout:-1 tag:0];
}


#pragma mark -  有客户端链接
- (void)socket:(GCDAsyncSocket *)sock didAcceptNewSocket:(GCDAsyncSocket *)newSocket{
    NSLog(@"有客服端连接服务器%@----%@",sock,newSocket);
    [self.clientArray addObject:newSocket];//需要将客户端的socket保存到数组,这样才能保证newSocket持续存在
    //当客户端一连接成功就发送数据给它
    NSMutableString *serverceStr = [NSMutableString string];
    [serverceStr appendString:@"欢迎红树林聊天室,这里都是环保精英"];
    // 向客户端socket发送数据
    [newSocket writeData:[serverceStr dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:0];
    
    [newSocket readDataWithTimeout:-1 tag:0];
    NSLog(@"当前有%ld客户端链接到服务器,name^%@",self.clientArray.count,sock);
    
    
}

#pragma mark - 读取客户端请求的数据
//当一个socket已经把数据读入内存中时被调用。如果发生错误则不被调用
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    NSString *clientString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    for (GCDAsyncSocket *forsocket in self.clientArray){
        if (forsocket != sock && clientString) { //不给自己发送消息
            [sock writeData:[clientString dataUsingEncoding:NSUTF8StringEncoding]  withTimeout:-1 tag:0];
        }
    }
    
//每次读完数据后都要调用一次监听数据的方法
    [sock readDataWithTimeout:-1 tag:0];
}


@end
