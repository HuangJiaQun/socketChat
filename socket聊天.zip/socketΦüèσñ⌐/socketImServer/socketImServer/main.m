//
//  main.m
//  socketImServer
//
//  Created by 黄嘉群 on 2020/11/27.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServerListener.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        ServerListener *server=[[ServerListener alloc]init];
        [server startListen];
                //保持主函数一直在允许循环
        [[NSRunLoop currentRunLoop]addPort:[NSPort port] forMode:NSDefaultRunLoopMode];
        [[NSRunLoop currentRunLoop]run];
    }
    return 0;
}
